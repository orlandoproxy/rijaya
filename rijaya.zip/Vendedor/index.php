<?php
include('../clases/conexion.php');
include('../clases/redireccion.php');

echo $_SESSION['Nombreusu'];

?>
<html>
<head>
<title>
</title>
</head>
<body>
	<a href="../clases/cerrar.php">Salir</a>
</body>
</html>