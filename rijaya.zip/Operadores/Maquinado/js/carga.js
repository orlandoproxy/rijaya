$(document).ready(function(){
   $("#lista").change(function () {
           $("#lista option:selected").each(function () {
            elegido=$(this).val();
            $.post("clases/proceso.php", { elegido: elegido }, function(data){
            $("#contenido").html(data);
            });
        });
   })
});
