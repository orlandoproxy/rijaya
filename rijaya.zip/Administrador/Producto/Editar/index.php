<?php
$id=$_GET['IDPro'];
echo "Editar.....";
echo $id;
?>