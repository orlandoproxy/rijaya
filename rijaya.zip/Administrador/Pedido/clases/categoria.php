<?php
session_start();
$_SESSION['estatus'] =  $_POST['elegido'];
?>