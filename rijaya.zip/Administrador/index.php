<?php

header('Location: Producto/');
?>